#!/usr/bin/env node
/**
 * Call God — Social Auto-Poster (Node.js + GitHub Actions version)
 * ------------------------------------------------------------------
 * Posts the next pending item in content/queue.json to Facebook
 * and Instagram using the Meta Graph API. Supports both images
 * and video (Reels on Instagram, native video on Facebook).
 *
 * ENV VARS REQUIRED (set as GitHub Actions secrets):
 *   META_PAGE_ACCESS_TOKEN   System user / page access token
 *   META_PAGE_ID             Facebook Page ID
 *   META_IG_USER_ID          Instagram Business Account ID
 *
 * QUEUE FILE: content/queue.json
 *   [
 *     {
 *       "id": "2026-07-20-gospel-luke6",
 *       "caption": "Today's Gospel... #CallGod",
 *       "mediaType": "image",              // "image" or "video"
 *       "mediaUrl": "https://raw.githubusercontent.com/.../luke6.jpg",
 *       "platforms": ["facebook", "instagram"],
 *       "status": "pending",
 *       "result": null,
 *       "error": null,
 *       "postedAt": null
 *     }
 *   ]
 *
 * NOTE: mediaUrl must be a PUBLICLY reachable HTTPS URL — Meta's
 * servers fetch the file themselves. A raw.githubusercontent.com
 * URL from a PUBLIC repo works well for this. GitHub's per-file
 * limit is 100MB, so keep video exports reasonably compressed
 * (1080p H.264 is plenty — platforms recompress anyway).
 */

const fs = require("fs");
const path = require("path");

const GRAPH_API_VERSION = "v21.0";
const GRAPH_BASE = `https://graph.facebook.com/${GRAPH_API_VERSION}`;
const QUEUE_PATH = path.join(__dirname, "..", "content", "queue.json");

const PAGE_ACCESS_TOKEN = process.env.META_PAGE_ACCESS_TOKEN;
const PAGE_ID = process.env.META_PAGE_ID;
const IG_USER_ID = process.env.META_IG_USER_ID;

// How long to wait for Instagram to finish processing a video
// container before giving up (containers can take anywhere from a
// few seconds to a couple of minutes depending on length/size).
const IG_VIDEO_POLL_INTERVAL_MS = 5000;
const IG_VIDEO_POLL_MAX_ATTEMPTS = 24; // ~2 minutes total

function assertEnv() {
  const missing = [];
  if (!PAGE_ACCESS_TOKEN) missing.push("META_PAGE_ACCESS_TOKEN");
  if (!PAGE_ID) missing.push("META_PAGE_ID");
  if (!IG_USER_ID) missing.push("META_IG_USER_ID");
  if (missing.length) {
    console.error(`Missing required env vars: ${missing.join(", ")}`);
    process.exit(1);
  }
}

function loadQueue() {
  if (!fs.existsSync(QUEUE_PATH)) {
    console.error(`Queue file not found at ${QUEUE_PATH}`);
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(QUEUE_PATH, "utf8"));
}

function saveQueue(queue) {
  fs.writeFileSync(QUEUE_PATH, JSON.stringify(queue, null, 2) + "\n", "utf8");
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------------- Facebook ----------------

async function postToFacebook({ caption, mediaUrl, mediaType }) {
  if (mediaType === "video") {
    const url = `${GRAPH_BASE}/${PAGE_ID}/videos`;
    const params = new URLSearchParams({
      description: caption,
      file_url: mediaUrl,
      access_token: PAGE_ACCESS_TOKEN,
    });
    const res = await fetch(url, { method: "POST", body: params });
    const data = await res.json();
    if (data.error) throw new Error(`Facebook video error: ${data.error.message}`);
    return data; // { id }
  }

  // image
  const url = `${GRAPH_BASE}/${PAGE_ID}/photos`;
  const params = new URLSearchParams({
    caption,
    url: mediaUrl,
    access_token: PAGE_ACCESS_TOKEN,
  });
  const res = await fetch(url, { method: "POST", body: params });
  const data = await res.json();
  if (data.error) throw new Error(`Facebook error: ${data.error.message}`);
  return data; // { id, post_id }
}

// ---------------- Instagram ----------------

async function createIgContainer({ caption, mediaUrl, mediaType }) {
  const createUrl = `${GRAPH_BASE}/${IG_USER_ID}/media`;
  const params =
    mediaType === "video"
      ? new URLSearchParams({
          media_type: "REELS", // posts as a Reel; use "VIDEO" for feed video if preferred
          video_url: mediaUrl,
          caption,
          access_token: PAGE_ACCESS_TOKEN,
        })
      : new URLSearchParams({
          image_url: mediaUrl,
          caption,
          access_token: PAGE_ACCESS_TOKEN,
        });

  const res = await fetch(createUrl, { method: "POST", body: params });
  const data = await res.json();
  if (data.error) {
    throw new Error(`Instagram (create container) error: ${data.error.message}`);
  }
  return data.id; // creation_id
}

/**
 * Videos aren't publishable immediately — Instagram needs time to
 * process them. Poll the container's status until it's FINISHED
 * (or ERROR, or we time out).
 */
async function waitForIgContainerReady(creationId) {
  for (let attempt = 0; attempt < IG_VIDEO_POLL_MAX_ATTEMPTS; attempt++) {
    const statusUrl = `${GRAPH_BASE}/${creationId}?fields=status_code&access_token=${PAGE_ACCESS_TOKEN}`;
    const res = await fetch(statusUrl);
    const data = await res.json();

    if (data.error) {
      throw new Error(`Instagram (status check) error: ${data.error.message}`);
    }

    if (data.status_code === "FINISHED") {
      return;
    }
    if (data.status_code === "ERROR") {
      throw new Error("Instagram video processing failed (status_code: ERROR).");
    }

    console.log(`  ...IG container status: ${data.status_code || "unknown"}, waiting`);
    await sleep(IG_VIDEO_POLL_INTERVAL_MS);
  }
  throw new Error("Timed out waiting for Instagram video to finish processing.");
}

async function publishIgContainer(creationId) {
  const publishUrl = `${GRAPH_BASE}/${IG_USER_ID}/media_publish`;
  const params = new URLSearchParams({
    creation_id: creationId,
    access_token: PAGE_ACCESS_TOKEN,
  });
  const res = await fetch(publishUrl, { method: "POST", body: params });
  const data = await res.json();
  if (data.error) {
    throw new Error(`Instagram (publish) error: ${data.error.message}`);
  }
  return data; // { id }
}

async function postToInstagram({ caption, mediaUrl, mediaType }) {
  const creationId = await createIgContainer({ caption, mediaUrl, mediaType });

  if (mediaType === "video") {
    console.log("  Waiting for Instagram to process the video...");
    await waitForIgContainerReady(creationId);
  }

  return publishIgContainer(creationId);
}

// ---------------- Main ----------------

async function main() {
  assertEnv();
  const queue = loadQueue();

  const nextIndex = queue.findIndex((item) => item.status === "pending");
  if (nextIndex === -1) {
    console.log("No pending posts in the queue. Nothing to do.");
    return;
  }

  const item = queue[nextIndex];
  const mediaType = item.mediaType || "image";
  const platforms = item.platforms || ["facebook", "instagram"];
  const result = {};
  let hadError = false;
  let errorMessage = "";

  console.log(`Posting item "${item.id}" (${mediaType}) to: ${platforms.join(", ")}`);

  if (platforms.includes("facebook")) {
    try {
      result.facebook = await postToFacebook({ ...item, mediaType });
      console.log("✅ Posted to Facebook:", result.facebook.id || result.facebook.post_id);
    } catch (err) {
      hadError = true;
      errorMessage += `FB: ${err.message}. `;
      console.error("❌ Facebook post failed:", err.message);
    }
  }

  if (platforms.includes("instagram")) {
    try {
      result.instagram = await postToInstagram({ ...item, mediaType });
      console.log("✅ Posted to Instagram:", result.instagram.id);
    } catch (err) {
      hadError = true;
      errorMessage += `IG: ${err.message}. `;
      console.error("❌ Instagram post failed:", err.message);
    }
  }

  queue[nextIndex] = {
    ...item,
    status: hadError ? "failed" : "posted",
    result,
    error: hadError ? errorMessage.trim() : null,
    postedAt: new Date().toISOString(),
  };

  saveQueue(queue);

  if (hadError) {
    process.exit(1); // makes the GitHub Actions run show as failed
  }
}

main().catch((err) => {
  console.error("Unexpected error:", err);
  process.exit(1);
});
